package com.muratov.springmvc.dto

data class User (
    val login: String,
    val password: String
)